# ADRT
Active Directory Report Tool

# Descrição
Como objetivo de colaborar com o dia-a-dia das tarefas diárias dos Administradores de Redes e Analista de Segurança da Informação eu optei em compartilhar esta ferramenta que desenvolvi utilizando PowerShell, HTML, JavaScript. O objetivo do ADRT é extrair informações úteis do Active Directory e exibir-las de forma amigável a fim de auxiliar na geração de indicadores e na realização de auditorias.

# adrt.ps1 - Menu via PowerShell
![](https://www.100security.com.br/images/adrt-02.jpg)

# index.html - Página Inicial de Relatórios
![](https://www.100security.com.br/images/adrt-10.jpg)

# Artigo 
www.100security.com.br/adrt

# Video
www.youtube.com/watch?v=KuEjGZSLPJE&t
