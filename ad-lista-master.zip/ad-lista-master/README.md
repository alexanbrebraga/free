# Active Directory – Lista de Usuários com PowerShell (HTML, CSV e E-mail)

# Descrição
Com este script é possível extrair todas as propriedades de um usuário do Active Directory além de receber um relatório por via e-mail.

Certamente com este relatório a administração e os controles sobre os usuários do Active Directory ficaram mais eficientes evitando que você tenha surpresas durante uma Auditoria de TI.

# Relatório em HTML
![](https://www.100security.com.br/images/ad-lista-05.jpg)

# Artigo 
www.100security.com.br/ad-lista
